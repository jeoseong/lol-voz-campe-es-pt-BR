import{n as e,r as t,t as n}from"./index-BNJAQcH0.js";var r=t(e()),i=`<!-- HUD SUPERIOR -->
  <div class="smite-top-hud">
    <div class="hud-left">
      <button class="smite-back-btn" id="backBtn" onclick="handleBack()">◄</button>
      <div class="wiki-title">SMITE WIKI & DATABASE</div>
    </div>
    <div id="mainBgUploadHeader" class="edit-only">
      <label class="file-upload-btn smite-btn-sm" style="position:relative; overflow:hidden; display:inline-block;">
        📷 Mudar Fundo
        <input type="file" accept="image/*" onchange="uploadMainBg(event)" style="position:absolute; left:0; top:0; opacity:0; width:100%; height:100%; cursor:pointer;">
      </label>
    </div>
  </div>

  <!-- VIEWPORT PRINCIPAL -->
  <div class="smite-viewport">

    <!-- MENU INICIAL -->
    <div class="screen-main-menu" id="screenMain">
      <div class="smite-nav-menu">
        <div class="nav-item" onclick="openSection('gods')">DEUSES</div>
        <div class="nav-item" onclick="openSection('voicebanks')">PACOTES DE VOZ</div>
      </div>
    </div>

    <!-- ROSTER DE SELEÇÃO DE DEUS -->
    <div class="screen-roster" id="screenRoster">
      <div class="roster-header">
        <span id="rosterTitle">SELECIONE UM DEUS</span>
        <div style="display:flex; gap:10px;">
          <input type="text" id="rosterSearch" class="smite-input" style="max-width: 200px;" placeholder="🔍 Buscar Deus..." oninput="renderRoster()">
          <button class="smite-btn-sm edit-only" onclick="openGodModal(null)">+ Novo Deus</button>
        </div>
      </div>
      <div class="gods-grid" id="rosterGrid"></div>
    </div>

    <!-- VISUALIZAÇÃO DO DEUS -->
    <div class="screen-god-view" id="screenGodView">
      <div class="god-sidebar">
        <button class="god-tab-btn active" id="tabBtnAbout" onclick="switchGodTab('about')">SOBRE</button>
        <button class="god-tab-btn" id="tabBtnSkins" onclick="switchGodTab('skins')">APARÊNCIAS</button>
        <button class="god-tab-btn" id="tabBtnLore" onclick="switchGodTab('lore')">HISTÓRIA</button>
        <button class="god-tab-btn" onclick="goToVoicebankFromGod()">PACOTE DE VOZ</button>
      </div>

      <div class="god-stage" id="godStage">
        <div style="display:flex; flex-direction:column; gap:2px; margin-bottom:5px;">
          <div style="font-size:1.8rem; color:#fff;" id="extGodName">IZANAMI</div>
          <div style="font-size:0.95rem; color:var(--wiki-blue-text);" id="extGodTitle">MATRON OF THE DEAD</div>
        </div>

        <div class="god-panel-card" id="godTabAbout">
          <button class="card-edit-btn edit-only" onclick="openAboutModal()">✏️</button>
          
          <div class="about-icons-row">
            <div class="about-icon-item">
              <img id="pantheonImg" class="about-icon-img" src="" alt="Panteão">
              <span id="pantheonName" class="about-icon-value">Japonês</span>
            </div>
            <div class="about-icon-item">
              <img id="typeImg" class="about-icon-img" src="" alt="Tipo">
              <span id="typeName" class="about-icon-value">Físico</span>
            </div>
            <div class="about-icon-item">
              <img id="classImg" class="about-icon-img" src="" alt="Classe">
              <span id="className" class="about-icon-value">Caçador</span>
            </div>
          </div>

          <div id="godMiniQuote" style="font-size:0.88rem; color:#cbd5e1; font-style:italic; border-left:2px solid var(--wiki-gold-border); padding-left:10px;">
            Devastem o campo de batalha com foices mortais.
          </div>
          <div id="godDifficulty" style="font-size:0.85rem; color:var(--wiki-blue-text);">
            DIFICULDADE - Média
          </div>
        </div>

        <div class="god-panel-card" id="godTabSkins" style="display:none;">
          <div style="display:flex; justify-content:flex-end; align-items:center; margin-bottom: 4px;">
            <button class="smite-btn-sm edit-only" onclick="openSkinModal(event, null)">+ Adicionar Skin</button>
          </div>
          <div class="gods-grid" id="godSkinsGrid"></div>
        </div>

        <div class="god-panel-card" id="godTabLore" style="display:none;">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <span style="color:var(--wiki-gold-title); font-size:0.95rem;">HISTÓRIA COMPLETA</span>
            <button class="smite-btn-sm edit-only" onclick="openLoreModal()">✏️ Editar História</button>
          </div>
          <div id="godLoreText" style="font-size:0.88rem; color:#cbd5e1; line-height:1.6; margin-top:8px; white-space:pre-wrap;"></div>
        </div>
      </div>
    </div>

    <!-- PACOTES DE VOZ -->
    <div class="screen-voicebank-view" id="screenVoicebankView">
      <div class="voicebank-container">
        
        <div class="wiki-side-box">
          <div class="wiki-title-header" id="vpTitle">Pacote Izanami Announcer</div>
          <img id="vpImage" class="wiki-god-image" src="" alt="Skin">
          
          <div class="wiki-summary-box">
            <button class="card-edit-btn edit-only" onclick="openVpHeaderModal()">✏️</button>
            <div class="wiki-summary-title">Informações</div>
            <table class="wiki-summary-table">
              <tr>
                <td class="wiki-summary-label">Dublador(a):</td>
                <td class="wiki-summary-val" id="vpDubber">Lisa Ortiz</td>
              </tr>
              <tr>
                <td class="wiki-summary-label">Data de Lançamento:</td>
                <td class="wiki-summary-val blue-link" id="vpReleaseDate">15/09/2016</td>
              </tr>
            </table>
          </div>

          <div class="wiki-btn-menu active" id="btnVpGod" onclick="switchVPMode('god')">VOZ DO DEUS</div>
          <div class="wiki-btn-menu" id="btnVpSkin" onclick="switchVPMode('skin')">VOZ POR APARÊNCIA</div>
          <div class="wiki-btn-menu" id="btnVpAnnouncer" onclick="switchVPMode('announcer')">Pacotes de locutor</div>
          <div class="wiki-btn-menu" id="btnVpVGS" onclick="switchVPMode('vgs')">Sistema guiado por voz</div>
        </div>

        <div class="vgs-tables-content" id="vpContentArea" style="position:relative;">

          <div id="vpDynamicPanel" style="background:#090e17; border:1px solid var(--wiki-gold-border); padding:16px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
              <h4 id="vpSectionTitle" style="color:var(--wiki-gold-title); font-size:1.1rem; text-transform:uppercase;">FALAS DE IZANAMI</h4>
            </div>
            <div id="voiceTreeContainer"></div>
          </div>

          <div id="vpSkinSelectionPanel" style="display:none; background:#090e17; border:1px solid var(--wiki-gold-border); padding:16px;">
            <h4 style="color:var(--wiki-gold-title); margin-bottom:12px; font-size:1.1rem; text-transform:uppercase;">APARÊNCIAS</h4>
            <div class="gods-grid" id="vpSkinCardsGrid"></div>
          </div>

          <div id="vgsContainerGroup" style="display:none; flex-direction:column; gap:15px;">
            <div id="vgsTablesList"></div>
          </div>

        </div>

      </div>

      <button class="floating-page-edit-btn edit-only" id="globalPageEditBtn" onclick="handleGlobalEditClick()">✏️</button>
    </div>

  </div>

  <!-- CHAT BAR INFERIOR (SMITE FIDEDIGNO) -->
  <div class="smite-bottom-hud">
    <div class="chat-bar-left">
      <button class="chat-bar-audio-tab" onclick="openSection('voicebanks')">Áudio</button>
      <div class="chat-bar-input-mock" id="statusAudio">De [PLAY] para escutar.</div>
    </div>
    <div class="chat-bar-right">
      <button class="chat-bar-gear-btn" onclick="openSettingsModal()" title="Configurações">
        <svg class="gear-icon-svg" viewBox="0 0 24 24">
          <path d="M12,15.5A3.5,3.5 0 0,1 8.5,12A3.5,3.5 0 0,1 12,8.5A3.5,3.5 0 0,1 15.5,12A3.5,3.5 0 0,1 12,15.5M19.43,12.97C19.47,12.65 19.5,12.33 19.5,12C19.5,11.67 19.47,11.34 19.43,11L21.54,9.37C21.73,9.22 21.78,8.95 21.66,8.73L19.66,5.27C19.54,5.05 19.27,4.96 19.05,5.05L16.56,6.05C16.04,5.66 15.5,5.32 14.87,5.07L14.49,2.42C14.46,2.18 14.25,2 14,2H10C9.75,2 9.54,2.18 9.51,2.42L9.13,5.07C8.5,5.32 7.96,5.66 7.44,6.05L4.95,5.05C4.73,4.96 4.46,5.05 4.34,5.27L2.34,8.73C2.21,8.95 2.27,9.22 2.46,9.37L4.57,11C4.53,11.34 4.5,11.67 4.5,12C4.5,12.33 4.53,12.65 4.57,12.97L2.46,14.63C2.27,14.78 2.21,15.05 2.34,15.27L4.34,18.73C4.46,18.95 4.73,19.03 4.95,18.95L7.44,17.94C7.96,18.34 8.5,18.68 9.13,18.93L9.51,21.58C9.54,21.82 9.75,22 10,22H14C14.25,22 14.46,21.82 14.49,21.58L14.87,18.93C15.5,18.68 16.04,18.34 16.56,17.94L19.05,18.95C19.27,19.03 19.54,18.95 19.66,18.73L21.66,15.27C21.78,15.05 21.73,14.78 21.54,14.63L19.43,12.97Z"/>
        </svg>
      </button>
    </div>
  </div>

  <div class="modal-overlay" id="settingsModal">
    <div class="modal-box">
      <div style="color:var(--wiki-gold-title); font-size:1.1rem; border-bottom:1px solid var(--wiki-gold-border); padding-bottom:6px;">CONFIGURAÇÕES</div>
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <span>Modo Edição:</span>
        <button class="smite-btn-sm" id="editToggleBtn" onclick="toggleEditModeSimple()">ON</button>
      </div>
      <div style="display:flex; flex-direction:column; gap:6px; margin-top:8px;">
        <label style="font-size:0.85rem; color:#94a3b8;">Volume do Áudio: <span id="volumeValText">100%</span></label>
        <input type="range" id="audioVolumeSlider" min="0" max="100" value="100" class="smite-input" oninput="updateAudioVolume(this.value)">
      </div>
      <button class="smite-btn-sm" style="align-self:flex-end; margin-top:10px;" onclick="closeModal('settingsModal')">Fechar</button>
    </div>
  </div>

  <div class="modal-overlay" id="voiceCategoryLineModal">
    <div class="modal-box">
      <div style="color:var(--wiki-gold-title); font-size:1.1rem; border-bottom:1px solid var(--wiki-gold-border); padding-bottom:6px;">GERENCIADOR DE FALAS E CATEGORIAS</div>
      <div class="form-group">
        <label>Tipo de Item:</label>
        <select id="modalTreeType" class="smite-select" onchange="toggleTreeModalFields()">
          <option value="line">Fala Individual</option>
          <option value="category">Categoria Principal</option>
          <option value="subcategory">Subcategoria</option>
        </select>
      </div>
      <div class="form-group" id="groupTreeTitle">
        <label id="labelTreeTitle">Título / Nome:</label>
        <input type="text" id="modalTreeTitle" class="smite-input">
      </div>
      <div class="form-group" id="groupTreeText">
        <label>Texto da Fala:</label>
        <input type="text" id="modalTreeText" class="smite-input">
      </div>
      <div class="form-group" id="groupTreeParent">
        <label>Pertence a qual Categoria/Subcategoria?</label>
        <select id="modalTreeParentSelect" class="smite-select"></select>
      </div>
      <div class="form-group" id="groupTreeAudio">
        <label>Arquivo de Áudio:</label>
        <input type="file" id="modalTreeAudioFile" class="smite-input" accept="audio/*">
      </div>
      <div style="display:flex; justify-content:space-between; align-items:center; margin-top:10px;">
        <button class="smite-btn-danger" id="btnDeleteTreeItem" onclick="deleteTreeItem()" style="display:none;" title="Excluir">🗑️</button>
        <div style="display:flex; gap:8px; margin-left:auto;">
          <button class="smite-btn-sm" onclick="closeModal('voiceCategoryLineModal')">Cancelar</button>
          <button class="smite-btn-sm" onclick="saveTreeModal()">Salvar</button>
        </div>
      </div>
    </div>
  </div>

  <div class="modal-overlay" id="editVgsModal">
    <div class="modal-box">
      <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--wiki-gold-border); padding-bottom:6px;">
        <span style="color:var(--wiki-gold-title); font-size:1.1rem;">GERENCIAR VGS</span>
        <button class="smite-btn-danger" id="btnDeleteEntireVgsBox" onclick="deleteEntireVgsBox()" title="Excluir Caixa VGS Inteira">🗑️</button>
      </div>
      
      <div class="form-group">
        <label>Título da Caixa VGS:</label>
        <input type="text" id="modalVgsBoxTitle" class="smite-input">
      </div>
      <hr style="border-color:var(--wiki-table-border); margin:4px 0;">
      <div style="font-size:0.85rem; color:var(--wiki-gold-title);">COMANDO/LINHA DE ÁUDIO:</div>
      <div class="form-group">
        <label>Atalho VGS (ex: A, G, T, VV):</label>
        <input type="text" id="modalVgsCode" class="smite-input">
      </div>
      <div class="form-group">
        <label>Resultado / Texto:</label>
        <input type="text" id="modalVgsResult" class="smite-input">
      </div>
      <div class="form-group">
        <label>É Categoria de Resultado?</label>
        <select id="modalVgsIsCat" class="smite-select">
          <option value="false">Não (Comando Normal)</option>
          <option value="true">Sim (Categoria de Resultado)</option>
        </select>
      </div>
      <div class="form-group">
        <label>Upload de Áudio (Arquivo da Coluna):</label>
        <div style="display:flex; gap:6px;">
          <input type="file" id="modalVgsAudioFile" class="smite-input" accept="audio/*">
          <button class="smite-btn-danger" id="btnRemoveAudioFile" onclick="removeAudioFromVgsRow()" title="Remover apenas o áudio" style="display:none;">🗑️</button>
        </div>
      </div>
      <div style="display:flex; justify-content:space-between; align-items:center; margin-top:10px;">
        <button class="smite-btn-danger" id="btnDeleteVgsRow" onclick="deleteVgsRow()" style="display:none;" title="Excluir Comando">🗑️</button>
        <div style="display:flex; gap:8px; margin-left:auto;">
          <button class="smite-btn-sm" onclick="closeModal('editVgsModal')">Cancelar</button>
          <button class="smite-btn-sm" onclick="saveVgsModal()">Salvar</button>
        </div>
      </div>
    </div>
  </div>

  <div class="modal-overlay" id="aboutModal">
    <div class="modal-box">
      <div style="color:var(--wiki-gold-title); font-size:1.1rem; border-bottom:1px solid var(--wiki-gold-border); padding-bottom:6px;">EDITAR INFORMAÇÕES DO DEUS</div>
      <div class="form-group"><label>Nome Panteão:</label><input type="text" id="aboutPantheonName" class="smite-input"></div>
      <div class="form-group"><label>Ícone Panteão (Arquivo):</label><input type="file" id="aboutPantheonImgFile" class="smite-input" accept="image/*"></div>
      <div class="form-group"><label>Nome Tipo:</label><input type="text" id="aboutTypeName" class="smite-input"></div>
      <div class="form-group"><label>Ícone Tipo (Arquivo):</label><input type="file" id="aboutTypeImgFile" class="smite-input" accept="image/*"></div>
      <div class="form-group"><label>Nome Classe:</label><input type="text" id="aboutClassName" class="smite-input"></div>
      <div class="form-group"><label>Ícone Classe (Arquivo):</label><input type="file" id="aboutClassImgFile" class="smite-input" accept="image/*"></div>
      <div class="form-group"><label>Frase Curta:</label><input type="text" id="aboutQuote" class="smite-input"></div>
      <div class="form-group"><label>Dificuldade:</label><input type="text" id="aboutDifficulty" class="smite-input"></div>
      <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:10px;">
        <button class="smite-btn-sm" onclick="closeModal('aboutModal')">Cancelar</button>
        <button class="smite-btn-sm" onclick="saveAboutModal()">Salvar</button>
      </div>
    </div>
  </div>

  <div class="modal-overlay" id="vpHeaderModal">
    <div class="modal-box">
      <div style="color:var(--wiki-gold-title); font-size:1.1rem; border-bottom:1px solid var(--wiki-gold-border); padding-bottom:6px;">EDITAR INFORMAÇÕES DE DUBLAGEM</div>
      <div class="form-group"><label>Dublador(a):</label><input type="text" id="modalVpDubber" class="smite-input"></div>
      <div class="form-group"><label>Data de Lançamento:</label><input type="text" id="modalVpReleaseDate" class="smite-input"></div>
      <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:10px;">
        <button class="smite-btn-sm" onclick="closeModal('vpHeaderModal')">Cancelar</button>
        <button class="smite-btn-sm" onclick="saveVpHeaderModal()">Salvar</button>
      </div>
    </div>
  </div>

  <div class="modal-overlay" id="godModal">
    <div class="modal-box">
      <div style="color:var(--wiki-gold-title); font-size:1.1rem; border-bottom:1px solid var(--wiki-gold-border); padding-bottom:6px;" id="godModalTitle">GERENCIAR DEUS</div>
      <div class="form-group"><label>Nome do Deus:</label><input type="text" id="modalGodName" class="smite-input"></div>
      <div class="form-group"><label>Título:</label><input type="text" id="modalGodTitle" class="smite-input"></div>
      <div class="form-group"><label>Imagem Padrão do Deus (Arquivo):</label><input type="file" id="modalGodImgFile" class="smite-input" accept="image/*"></div>
      <div style="display:flex; justify-content:space-between; align-items:center; margin-top:10px;">
        <button class="smite-btn-danger" id="btnDeleteGod" onclick="deleteCurrentGod()" style="display:none;" title="Excluir Deus">🗑️</button>
        <div style="display:flex; gap:8px; margin-left:auto;">
          <button class="smite-btn-sm" onclick="closeModal('godModal')">Cancelar</button>
          <button class="smite-btn-sm" onclick="saveGodModal()">Salvar</button>
        </div>
      </div>
    </div>
  </div>

  <div class="modal-overlay" id="loreModal">
    <div class="modal-box">
      <div style="color:var(--wiki-gold-title); font-size:1.1rem; border-bottom:1px solid var(--wiki-gold-border); padding-bottom:6px;">EDITAR HISTÓRIA COMPLETA</div>
      <div class="form-group"><label>História:</label><textarea id="loreTextarea" class="smite-textarea" rows="8"></textarea></div>
      <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:10px;">
        <button class="smite-btn-sm" onclick="closeModal('loreModal')">Cancelar</button>
        <button class="smite-btn-sm" onclick="saveLoreModal()">Salvar</button>
      </div>
    </div>
  </div>

  <div class="modal-overlay" id="editSkinModal">
    <div class="modal-box">
      <div style="color:var(--wiki-gold-title); font-size:1.1rem; border-bottom:1px solid var(--wiki-gold-border); padding-bottom:6px;">GERENCIAR APARÊNCIA / SKIN</div>
      <div class="form-group"><label>Nome da Skin:</label><input type="text" id="modalSkinName" class="smite-input"></div>
      <div class="form-group">
        <label>Tipo de Skin (Destaque do Card):</label>
        <select id="modalSkinTier" class="smite-select">
          <option value="PADRÃO">PADRÃO (Sem Banner Superior)</option>
          <option value="PROMOCIONAL">PROMOCIONAL</option>
          <option value="EXCLUSIVO">EXCLUSIVO</option>
          <option value="LIMITADO">LIMITADO</option>
          <option value="UNLIMITED">UNLIMITED / ILIMITADO</option>
          <option value="CROSSOVER">CROSSOVER</option>
          <option value="CROSS-GEN">CROSS-GEN</option>
        </select>
      </div>
      <div class="form-group"><label>Imagem da Skin (Arquivo):</label><input type="file" id="modalSkinImgFile" class="smite-input" accept="image/*"></div>
      <div style="display:flex; justify-content:space-between; align-items:center; margin-top:10px;">
        <button class="smite-btn-danger" id="btnDeleteSkinCard" onclick="deleteCurrentSkinCard()" style="display:none;" title="Excluir Skin">🗑️</button>
        <div style="display:flex; gap:8px; margin-left:auto;">
          <button class="smite-btn-sm" onclick="closeModal('editSkinModal')">Cancelar</button>
          <button class="smite-btn-sm" onclick="saveSkinModal()">Salvar</button>
        </div>
      </div>
    </div>
  </div>
`,a=n();function o(){return(0,r.useEffect)(()=>{let e=window,t=()=>e.bootSmiteWiki?.();if(e.__smiteWikiLoaded){t();return}if(e.__smiteWikiLoading){let e=()=>t();return window.addEventListener(`smite-wiki-ready`,e,{once:!0}),()=>window.removeEventListener(`smite-wiki-ready`,e)}e.__smiteWikiLoading=!0;let n=document.createElement(`script`);n.src=`/smite/wiki.js`,n.async=!1,n.onload=()=>{e.__smiteWikiLoaded=!0,window.dispatchEvent(new Event(`smite-wiki-ready`)),t()},document.body.appendChild(n)},[]),(0,a.jsx)(`div`,{id:`smite-app`,className:`smite-app on-screen-main`,dangerouslySetInnerHTML:{__html:i}})}export{o as component};